package com.example.githubexample

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

interface GopalApi
{
    @GET("users/{username}/repos")

    suspend fun getdata(@Path("username")name: String):Response<List<Pojo>>
}