package com.example.githubexample

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MainActivity : AppCompatActivity() {

    lateinit var edit:EditText

    lateinit var tvdata:TextView

    lateinit var pd:ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edit=findViewById(R.id.et1)
        tvdata=findViewById(R.id.tv)
    }

    fun getinfo(view: View)
    {

        val d=edit.text.toString()

        val moshi=Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

        val retro=
            Retrofit.Builder().baseUrl("https://api.github.com/").
            addConverterFactory(MoshiConverterFactory.create(moshi)).build()


        val api:GopalApi=retro.create(GopalApi::class.java)

        pd=ProgressDialog(this)

        pd.setTitle("loading")

        pd.setMessage("please wait")

        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER)

        pd.show()

        GlobalScope.launch(Dispatchers.IO){

            val response=api.getdata(d)

            if (response.isSuccessful){

                withContext(Dispatchers.Main){

                    tvdata.text=""

                    val res=response.body()

                    for (i in res!!)
                    {
                        tvdata.append("\n"+i.name)

                    }

                    pd.dismiss()
                }
            }
        }





0odex1q




    }
}
