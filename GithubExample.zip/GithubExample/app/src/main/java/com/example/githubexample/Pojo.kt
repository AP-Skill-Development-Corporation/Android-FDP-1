package com.example.githubexample

data class Pojo(val login:String?=null,val name:String?=null)